//
//  MyCustomWindow.m
//  SDL Custom View App
//
//  Created by Darrell Walisser on Fri Jul 18 2003.
//  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
//

#import "MyCustomWindow.h"


@implementation MyCustomWindow

@end
