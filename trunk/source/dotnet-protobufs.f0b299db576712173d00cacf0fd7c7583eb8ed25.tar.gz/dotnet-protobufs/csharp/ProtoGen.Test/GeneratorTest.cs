﻿using NUnit.Framework;

namespace ProtoGen {
  [TestFixture]
  public class GeneratorTest {
  }
}
