﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace ProtoGen {
  /// <summary>
  /// Tests for the dependency resolution in Generator.
  /// </summary>
  [TestFixture]
  public class DependencyResolutionTest {

    [Test]
    public void TwoDistinctFiles() {
    }
  }
}
