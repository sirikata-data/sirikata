def install():
    import _codecs_errors
