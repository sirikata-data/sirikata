def install():
    import encodings
