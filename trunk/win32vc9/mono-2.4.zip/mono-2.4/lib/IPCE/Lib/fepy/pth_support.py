def install():
    import _pth_support
